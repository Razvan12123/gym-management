#ifndef MEMBER_H
#define MEMBER_H

#include "Date.h"
#include <string>
using namespace std;

class Member {
private:
    string name;
    int age;
    string membershipType;
    Date startDate;
    bool active;

public:
    Member(string name, int age, string membershipType, Date startDate);

    string getName();
    int getAge();
    string getMembershipType();
    Date getStartDate();
    bool isActive();
    void setActive(bool status);
    void setMembershipType(string newType);

    bool isExpired(Date currentDate);
    void renew(Date currentDate);
    void cancel();
    static int calculateDaysDifference(Date d1, Date d2);

    void printDetails();
};

#endif
