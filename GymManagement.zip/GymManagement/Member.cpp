#include "Member.h"
#include <iostream>
#include <ctime>
using namespace std;

Member::Member(string name, int age, string membershipType, Date startDate) {
    this->name = name;
    this->age = age;
    this->membershipType = membershipType;
    this->startDate = startDate;
    this->active = true;
}

string Member::getName() { return name; }
int Member::getAge() { return age; }
string Member::getMembershipType() { return membershipType; }
Date Member::getStartDate() { return startDate; }
bool Member::isActive() { return active; }

void Member::setActive(bool status) { active = status; }
void Member::setMembershipType(string newType) { membershipType = newType; }

bool Member::isExpired(Date currentDate) {
    int days = calculateDaysDifference(startDate, currentDate);
    return days > 30;
}

void Member::renew(Date currentDate) {
    startDate = currentDate;
    active = true;
    cout << "Abonamentul a fost reinnoit pentru: " << name << endl;
}

void Member::cancel() {
    active = false;
    cout << "Abonamentul a fost anulat pentru: " << name << endl;
}

int Member::calculateDaysDifference(Date d1, Date d2) {
    struct tm t1 = {0}, t2 = {0};
    t1.tm_mday = d1.day;
    t1.tm_mon = d1.month - 1;
    t1.tm_year = d1.year - 1900;

    t2.tm_mday = d2.day;
    t2.tm_mon = d2.month - 1;
    t2.tm_year = d2.year - 1900;

    time_t time1 = mktime(&t1);
    time_t time2 = mktime(&t2);

    return difftime(time2, time1) / (60 * 60 * 24);
}

void Member::printDetails() {
    cout << "Nume: " << name << ", Varsta: " << age
         << ", Tip abonament: " << membershipType
         << ", Data inceperii: " << startDate.day << "-" << startDate.month << "-" << startDate.year
         << ", Status: " << (active ? "Activ" : "Inactiv") << endl;
}
