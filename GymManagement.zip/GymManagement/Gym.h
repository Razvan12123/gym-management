#ifndef GYM_H
#define GYM_H

#include "Member.h"
#include <vector>
using namespace std;

class Gym {
private:
    vector<Member> members;

public:
    void add(string name, int age, string membershipType, Date startDate);
    void displayMembers();
    void selectMemberForStatusCheck(Date currentDate);
    void promptRenewOrCancel(Member &member, Date currentDate);
};

#endif
