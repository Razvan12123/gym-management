#include "Gym.h"
#include <iostream>
using namespace std;

int main() {
    Gym gym;
    cout << "***** Managementul salii de fitness  *****" << endl;
    int choice;

    while (true) {
        cout << "\n1. Adauga membru" << endl;
        cout << "2. Afiseaza toti membrii" << endl;
        cout << "3. Selecteaza un membru pentru verificare" << endl;
        cout << "0. Iesire" << endl;
        cout << "Introduceti alegerea: ";
        cin >> choice;

        if (choice == 1) {
            string name, membershipType, dateStr;
            int age;
            cout << "Introduceti numele: ";
            cin >> name;
            cout << "Introduceti varsta: ";
            cin >> age;
            cout << "Introduceti tipul abonamentului (Basic/Premium): ";
            cin >> membershipType;
            cout << "Introduceti data inceperii (dd-mm-yyyy): ";
            cin >> dateStr;
            Date startDate = parseDate(dateStr);
            gym.add(name, age, membershipType, startDate);

        } else if (choice == 2) {
            gym.displayMembers();

        } else if (choice == 3) {
            string dateStr;
            cout << "Introduceti data curenta (dd-mm-yyyy): ";
            cin >> dateStr;
            Date currentDate = parseDate(dateStr);
            gym.selectMemberForStatusCheck(currentDate);

        } else if (choice == 0) {
            break;
        } else {
            cout << "Alegere invalida!\n";
        }
    }

    return 0;
}
