#include "Date.h"
#include <sstream>

Date parseDate(string dateStr) {
    Date date;
    stringstream ss(dateStr);
    char dash;
    ss >> date.day >> dash >> date.month >> dash >> date.year;
    return date;
}
