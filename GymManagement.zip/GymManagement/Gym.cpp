#include "Gym.h"
#include <iostream>
using namespace std;

void Gym::add(string name, int age, string membershipType, Date startDate) {
    Member member(name, age, membershipType, startDate);
    members.push_back(member);
    cout << "Membru adaugat cu succes.\n";
}

void Gym::displayMembers() {
    if (members.empty()) {
        cout << "Nu exista membri.\n";
        return;
    }

    cout << "\nLista membrilor:\n";
    for (int i = 0; i < members.size(); ++i) {
        cout << i + 1 << ". ";
        members[i].printDetails();
    }
}

void Gym::selectMemberForStatusCheck(Date currentDate) {
    displayMembers();

    if (members.empty()) return;

    int choice;
    cout << "Introduceti numarul membrului pentru verificare: ";
    cin >> choice;

    if (choice < 1 || choice > members.size()) {
        cout << "Alegere invalida.\n";
        return;
    }

    Member &member = members[choice - 1];

    if (member.isExpired(currentDate)) {
        cout << "Abonamentul pentru " << member.getName() << " a expirat.\n";
        promptRenewOrCancel(member, currentDate);
    } else {
        cout << "Abonamentul pentru " << member.getName() << " este inca activ.\n";
    }
}

void Gym::promptRenewOrCancel(Member &member, Date currentDate) {
    char choice;
    cout << "Pentru " << member.getName() << ", alegeti o optiune:\n";
    cout << "r - Reinoire abonament\n";
    cout << "c - Anulare abonament\n";
    cout << "t - Schimbare tip abonament\n";
    cout << "Introduceti opțiunea: ";
    cin >> choice;

    if (choice == 'r' || choice == 'R') {
        member.renew(currentDate);
    } else if (choice == 'c' || choice == 'C') {
        member.cancel();
    } else if (choice == 't' || choice == 'T') {
        string newType;
        cout << "introduceti noul tip de abonament (Basic/Premium): ";
        cin >> newType;

        if (newType == "Basic" || newType == "Premium") {
            member.setMembershipType(newType);
            cout << "Tipul abonamentului a fost schimbat cu succes.\n";
        } else {
            cout << "Tip de abonament invalid. Nu sa efectuat nicio schimbare.\n";
        }
    } else {
        cout << "Optiune invalidă. Nu sa efectuat nicio schimbare.\n";
    }
}
