#ifndef DATE_H
#define DATE_H

#include <string>
using namespace std;

struct Date {
    int day, month, year;
};

Date parseDate(string dateStr);

#endif
